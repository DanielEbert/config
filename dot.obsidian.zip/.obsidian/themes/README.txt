added:  font-family: "Hack", monospace;
added: vim cursor color https://forum.obsidian.md/t/how-to-change-block-cursor-color-vim-mode/7429/7